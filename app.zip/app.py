players = {}

# Register Players
while True:
    print("\n1. Add Player")
    print("2. Start Match")
    choice = input("Enter your choice: ")

    if choice == "1":
        name = input("Enter player name: ")
        mobile = input("Enter mobile number: ")
        players[mobile] = name
        print("Player added successfully!")

    elif choice == "2":
        if len(players) < 2:
            print("Add at least 2 players.")
            continue

        print("\nAvailable Players:")
        for mobile, name in players.items():
            print(name, "-", mobile)

        striker_mobile = input("Enter striker mobile number: ")
        if striker_mobile not in players:
            print("Player not found!")
            continue

        striker = players[striker_mobile]

        runs = 0
        balls = 0

        while True:
            print("\nCurrent Batsman:", striker)
            print("Runs:", runs)
            print("Balls:", balls)

            score = input("Enter runs (0,1,2,3,4,6), W for wicket, Q to quit: ")

            if score.upper() == "Q":
                break

            elif score.upper() == "W":
                print(striker, "is OUT!")

                new_mobile = input("Enter new batsman's mobile number: ")

                if new_mobile in players:
                    striker = players[new_mobile]
                else:
                    print("Player not found!")
                    continue

                balls += 1

            else:
                try:
                    r = int(score)
                    runs += r
                    balls += 1
                except:
                    print("Invalid input!")

        overs = f"{balls//6}.{balls%6}"
        print("\nMatch Summary")
        print("Batsman:", striker)
        print("Runs:", runs)
        print("Balls:", balls)
        print("Overs:", overs)
        break

    else:
        print("Invalid Choice")